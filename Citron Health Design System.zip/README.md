# Citron Health — Design System

A design system for **Citron Health**, a synthetic ambulatory surgery center (ASC)
and **surgical revenue-cycle copilot**. Citron helps coders, billers, denial
specialists, auth specialists, and managers **identify work, review cited
evidence, understand why it matters, and generate reviewer-safe drafts**.

The product is **deterministic-first**. Synthetic rules, synthetic payer
policies, and synthetic contract references are the source of truth. Copilot
output is **assistive only** — every surfaced item cites evidence and every
draft requires human review.

> ⚠️ **Synthetic data only. No PHI. No external APIs. No real payer submission.**
> This guardrail is a *product feature* and shows up in the UI itself — treat it
> as a first-class design element, never an afterthought.

---

## Sources

This system was built by studying the product's source repository. The
codebase ships a deterministic Python pipeline with a **bare Streamlit UI**
(default components, no custom styling, fonts, color, or brand). So this design
system **establishes** a visual language grounded in the product's domain,
content, and tone — it does not recreate an existing visual identity (there
wasn't one to recreate).

- **GitHub:** [`parrak/pixel`](https://github.com/parrak/pixel) — *"ASC RCM Copilot Lite"*
  - `README.md` — positioning, guardrails, supported opportunities, eval snapshot
  - `docs/PRODUCT_SPEC.md` — north star, users, core product areas, boundaries
  - `docs/ASC_RCM_BUILD_PLAN.md` — data model, detectors, reviewer packets, UI pages
  - `docs/COPILOT_DEMO_SCRIPT.md` — demo flow + featured synthetic scenarios
  - `docs/COMPLIANCE_GUARDRAILS.md` — the non-negotiable safety language
  - `docs/DATA_DICTIONARY.md` — entity shapes (cases, flags, opportunities, packets)
  - `data/asc_cases/*.json` — synthetic case bundles (real content used in the UI kit)
  - `asc_rcm_lite/copilot/*.py` — exact reviewer-safe draft language
  - `ui/streamlit_app.py` — the surface map (the ten workbench tabs)

**Readers with repo access should explore `parrak/pixel` further** — especially
the `docs/` folder and `data/asc_cases/` fixtures — to build higher-fidelity
designs grounded in the real deterministic outputs.

---

## The product, in one diagram

```
synthetic ASC case JSON
  → normalized case bundle
  → case / claim evidence graph
  → deterministic RCM detectors        ← source of truth
  → evidence-cited opportunities
  → priority-scored work queue
  → reviewer packets + reviewer-safe drafts   ← copilot, assistive only
  → eval metrics + manager summaries
  → command-center UI
```

### Users (roles)
Coder · Biller · Denial specialist · Auth specialist · Manager

### Core surfaces (from `ui/streamlit_app.py`)
Manager Dashboard · Work Queue · Coding Copilot · A/R Copilot ·
Denial & Appeal Copilot · Workflow Assistant · Payer Intelligence ·
Case Detail · Audit Trace · Eval Results

### Opportunity domains
- **Coding QA** — modifier risk, laterality mismatch, bundled-procedure risk, missing implant charge, documentation insufficiency, site-of-service, CPT/op-note mismatch
- **A/R** — high-dollar aging, 60/90/120+ buckets, near-deadline work, stale follow-up, underpayment recovery
- **Denials** — prior auth, medical necessity, modifier/bundling, timely filing
- **Workflow** — role-aware action suggestions, audit trace, queue routing, escalation
- **Payer intelligence** — denial patterns, payer friction, top root causes, recoverable A/R

---

## Content Fundamentals

The product's voice is **calm, exact, and reviewer-safe**. It never asserts a
billing or clinical conclusion — it *frames work for a human to decide*. This is
the single most important thing to get right; the entire brand rests on
trustworthy, hedged, evidence-first language.

### Voice & tone
- **Assistive, never authoritative.** The copilot proposes; the reviewer
  decides. Copy is in the register of a careful senior colleague handing you a
  prepared file — not an oracle.
- **Quiet confidence over excitement.** No hype, no exclamation, no "AI magic."
- **Evidence before recommendation.** Always show *why* (cited source) before
  *what to do*. The UI surfaces evidence first, action second.

### Person & address
- The product addresses the reviewer's **work**, not the reviewer personally —
  more "Review whether…" than "You should…". Imperatives are softened into
  review prompts.
- First person plural ("we") is essentially absent. The system is a tool, not a
  voice with opinions.

### Required / safe phrasing (lift these verbatim)
- "possible opportunity for **reviewer validation**"
- "**Review whether** retro authorization or a documented emergency exception is available."
- "please **verify against source documentation**"
- "**if appropriate after human review**"
- "**Human review is required** before any payer outreach, appeal, correction, or write-off decision."
- "This draft does not guarantee payment or a final coding outcome."
- Every draft ends with **`Evidence reviewed: SRC-002-POLICY, SRC-002-835.`**

### Banned phrasing (the product validates against these)
> `submit this claim` · `bill this code` · `payer will deny` · `payer must pay` ·
> `guaranteed reimbursement` · `patient has` · `confirmed` · `compliant code` ·
> `definitely incorrect`

### Casing & mechanics
- **Sentence case** everywhere — headings, buttons, table headers. No Title Case,
  no ALL CAPS except short eyebrow labels (e.g. `WORK QUEUE`, tracked +8%).
- **Codes and identifiers are sacred and always monospaced**: CPT `64483`,
  claim `CLM-002`, denial code `CO-197`, evidence `SRC-002-POLICY`, case
  `ASC-CASE-002`. Never paraphrase them.
- **Money** is monospaced, tabular, with explicit currency: `$3,600.00`,
  `$76,400.00`. Amounts at risk are first-class data.
- **Dates** ISO-style in data contexts (`2026-02-05`), humanized in prose.
- **Priority bands** are a fixed three-value vocabulary: **High / Medium / Low**.

### No emoji
Emoji are **not** part of the brand. The one exception is the compliance/guardrail
warning, which the source app renders as a standard warning affordance — use a
Lucide icon, never an emoji. Tone is professional-clinical, not playful.

### Example, in-product
> **Missing prior authorization — possible opportunity for reviewer validation**
> Claim `CLM-002` (`$3,600.00`, payer `PAYER-COM-B`) was denied `CO-197`
> "precertification authorization absent." Review whether retro authorization or
> a documented emergency exception is available. *Human review is required
> before any payer outreach.* Evidence: `SRC-002-POLICY`, `SRC-002-835`.

---

## Visual Foundations

The look is **Stripe-caliber calm and confidence, tuned for clinical/financial
trust**: generous whitespace, crisp hairline structure, restrained color with
one confident accent, and refined type. Fresh and a little delightful, but never
at the expense of legibility for a reviewer scanning dollars and deadlines all
day.

### Color
- **Canvas** is a warm off-white (`#FAFAF7`), not pure white — softer on the
  eyes for long review sessions. Surfaces are true white and lift off the canvas
  with soft shadow + hairline border.
- **Pine green (`#15634D`)** is the trustworthy primary — buttons, links, active
  nav, selected states. Healthcare reads "green = good/safe"; pine keeps it
  grown-up rather than minty.
- **Citron (`#CFE84F`)** is the *signature* accent (the brand is *Citron*). Used
  sparingly and with intent: the logo mark, focus glow on brand moments, a thin
  active-tab underline, a highlight behind a key metric, the cited-evidence
  marker. Never as a large fill behind text (it's a high-chroma yellow-green) and
  always paired with `--citron-ink` for any text on it.
- **Semantic palette maps to priority bands and claim states:**
  `--danger-600` clay red = High priority / denied / at-risk ·
  `--warning-600` amber = Medium / A/R aging / attention ·
  `--info-600` blue = Low / informational ·
  `--success-600` (pine family) = paid / clean / resolved.
  These are muted, not saturated — they sit calmly in dense tables.
- **Imagery vibe:** the product has none and needs little. Where imagery appears
  it should be cool, clean, documentary (operating-suite or office, desaturated).
  This system favors **data and structure over photography**.

### Type
- **Hanken Grotesk** for all UI — a warm, precise humanist grotesk. Headings use
  tight negative tracking (`-0.012` to `-0.02em`) and weight 600–700.
- **IBM Plex Mono** for **every code, ID, denial code, evidence ref, and dollar
  amount.** This is the system's signature decision: the mono visually encodes
  "deterministic, auditable, machine-verified" and makes the dense identifier
  soup scannable. Tabular numerals on all money.
- Sentence-case headings; uppercase only for short tracked eyebrow labels.
- Minimum body size 13.5px; table/caption text never below 12px.

### Spacing & layout
- **4px base scale.** Comfortable but efficient density — this is a workbench,
  not a marketing page. Generous outer padding (`24–32px`), tighter internal
  rhythm in tables and cards.
- **Fixed left sidebar** for case/role context + global metrics; **tabbed or
  segmented** primary surfaces; main column scrolls. Compliance banner is
  persistent near the top.
- Content max-width is generous; tables go full-width.

### Borders, radius, elevation
- **Hairline borders** (`#E6E8E1`) do most of the structural work; shadows are
  used sparingly for true elevation (menus, modals, the focused work item).
- **Radius:** 8–10px for buttons/inputs/chips, 14px for cards/panels, pill
  (`999px`) for status badges and filter chips. Nothing sharp; nothing bubbly.
- **Shadow system** is soft and green-tinted (`rgba(20,32,28,…)`) rather than
  neutral gray, so elevation feels of-a-piece with pine. Four steps: `xs` hairline
  lift → `lg` for overlays. No hard drop shadows, no neumorphism.
- **Cards:** white surface, 14px radius, 1px `--border`, `--shadow-sm`. On hover
  for interactive cards: border darkens to `--border-strong` and `--shadow-md`.

### Motion
- **Subtle and quick.** 120–180ms ease-out for hovers and toggles; 200–260ms for
  panels/sheets. Easing `cubic-bezier(0.2, 0.7, 0.2, 1)`.
- **Delight is restrained:** a citron focus glow, a soft count-up on a metric, a
  gentle row highlight when a work item is actioned. **No bounces, no infinite
  loops, no parallax.** A reviewer should never wait on an animation.
- Respect `prefers-reduced-motion` — content is fully visible without motion.

### States (apply consistently)
- **Hover:** primary buttons darken one step (`pine-600 → pine-700`); neutral
  rows/cards get `--surface-2` fill or a darkened border. Links get pine + subtle
  underline.
- **Press:** darken + `transform: translateY(0.5px)` (no big scale).
- **Focus:** visible ring — `--ring-pine` on standard controls, `--ring-citron`
  for brand/key moments. Never remove outlines.
- **Selected/active:** pine tint background (`--pine-100`) + pine text, often a
  2px citron or pine left/under accent.
- **Disabled:** `--ink-400` text, `--surface-2` fill, no shadow, 60% feel.

### Transparency & blur
Used only for overlays: modal scrims `rgba(21,32,28,0.45)`; sticky headers may
use a `backdrop-filter: blur(8px)` over a translucent surface. Not decorative.

---

## Iconography

The source codebase ships **no icon assets** (bare Streamlit). This system
standardizes on **[Lucide](https://lucide.dev)** — clean, consistent 1.75px-stroke
outline icons that match the calm, precise, Stripe-adjacent aesthetic.

> ⚠️ **Substitution flag:** Lucide is a chosen substitute, not a brand asset
> inherited from the repo. If Citron later adopts an official icon set, swap the
> CDN link and re-document here.

- **Style:** outline (stroke) only, never filled, never duotone. Stroke weight
  `1.75`, round caps/joins, 20–24px default box. Icons inherit `currentColor` and
  sit at `--ink-500`/`--ink-700`, taking pine when active.
- **Loaded from CDN** in the UI kit: `https://unpkg.com/lucide@latest`.
- **Common glyphs in use:** `layout-dashboard` (Manager Dashboard),
  `list-checks` (Work Queue), `file-search` / `scan-line` (Coding QA),
  `circle-dollar-sign` (A/R), `gavel` / `file-warning` (Denials),
  `workflow` (Workflow Assistant), `network` (Payer Intelligence),
  `shield-check` (compliance/guardrails), `quote` / `link` (evidence citation),
  `clock` (deadlines/aging), `chevron-right` (drill-in), `circle-check` (resolved).
- **Priority** is communicated by **color + a pill label**, not by icon alone
  (accessibility). An optional small dot precedes the label.
- **No emoji, no unicode glyph hacks, no hand-rolled SVG icons.** The only bespoke
  SVG in this system is the **logo mark** (`assets/logo-mark.svg`), which is brand
  identity, not iconography.

### Logo
- `assets/logo-mark.svg` — the symbol: a citrus-slice in citron on a pine
  rounded tile. Scales cleanly to 24px (favicon/nav) up to hero sizes.
- **Wordmark lockup** = mark + "Citron Health" set in Hanken Grotesk 700, tight
  tracking, `--ink-900` (or white on dark). Rendered in HTML in the UI kit and
  Brand preview cards so the typeface always resolves. Clear space = the mark's
  corner radius on all sides.

---

## Index — what's in this folder

| Path | What it is |
|---|---|
| `README.md` | This file — product context, content & visual foundations, iconography |
| `colors_and_type.css` | Design tokens: color, type, spacing, radius, shadow CSS variables + helper classes |
| `SKILL.md` | Agent-Skill manifest so this system can be used inside Claude Code |
| `assets/logo-mark.svg` | The Citron Health logo mark |
| `preview/` | Design-system cards (color, type, spacing, components, brand) shown in the Design System tab |
| `ui_kits/copilot/` | UI kit for the **Citron RCM Copilot** command center — `README.md`, `index.html`, JSX components |
| `data/asc_cases/*.json` | Synthetic case fixtures imported from `parrak/pixel` (real content for the UI kit) |

### UI kits
- **`ui_kits/copilot/`** — the surgical revenue-cycle command center: Manager
  Dashboard, Work Queue, and an evidence-cited Reviewer / Copilot detail view,
  as an interactive click-through prototype.
