/* @ds-bundle: {"format":3,"namespace":"CitronHealthDesignSystem_c2ca5e","components":[],"sourceHashes":{"ui_kits/copilot/components.jsx":"6fd4c94adbbf","ui_kits/copilot/dashboard.jsx":"d4f13f96b6d8","ui_kits/copilot/data.js":"a237dc5e5ba9","ui_kits/copilot/icons.js":"6f4ec34a5016","ui_kits/copilot/payer.jsx":"404bf3190f0f","ui_kits/copilot/workqueue.jsx":"6fca5d069d95"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CitronHealthDesignSystem_c2ca5e = window.CitronHealthDesignSystem_c2ca5e || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/copilot/components.jsx
try { (() => {
// Shared chrome + primitives for the Citron RCM Copilot kit.
const {
  useState
} = React;
const NAV = [{
  id: 'dashboard',
  label: 'Manager dashboard',
  icon: 'layout-dashboard'
}, {
  id: 'queue',
  label: 'Work queue',
  icon: 'list-checks',
  countKey: 'all'
}, {
  id: 'coding',
  label: 'Coding QA',
  icon: 'scan-line',
  countKey: 'coding'
}, {
  id: 'ar',
  label: 'A/R follow-up',
  icon: 'circle-dollar-sign',
  countKey: 'ar-follow-up'
}, {
  id: 'denials',
  label: 'Denials & appeals',
  icon: 'scale',
  countKey: 'denial'
}, {
  id: 'payer',
  label: 'Payer intelligence',
  icon: 'network'
}];
function Badge({
  band
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: 'badge ' + band.toLowerCase()
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), band);
}
function StatusPill({
  item
}) {
  if (item.status === 'denied') return /*#__PURE__*/React.createElement("span", {
    className: "status denied"
  }, "Denied \xB7 ", item.denialCode);
  if (item.queue === 'ar-follow-up') return /*#__PURE__*/React.createElement("span", {
    className: "status open"
  }, "Open A/R \xB7 120+ days");
  return /*#__PURE__*/React.createElement("span", {
    className: "status open"
  }, "Open \xB7 in review");
}
function Sidebar({
  view,
  setView,
  role,
  setRole,
  counts
}) {
  return /*#__PURE__*/React.createElement("aside", {
    className: "sidebar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark.svg",
    width: "30",
    height: "30",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", {
    className: "wm"
  }, "Citron", /*#__PURE__*/React.createElement("b", null, " Health"))), /*#__PURE__*/React.createElement("div", {
    className: "role"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lab"
  }, "Viewing as"), /*#__PURE__*/React.createElement("select", {
    value: role,
    onChange: e => setRole(e.target.value)
  }, CITRON_DATA.roles.map(r => /*#__PURE__*/React.createElement("option", {
    key: r
  }, r)))), /*#__PURE__*/React.createElement("nav", {
    className: "nav"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nav-sect"
  }, "Command center"), NAV.map(n => /*#__PURE__*/React.createElement("button", {
    key: n.id,
    className: 'nav-item' + (view === n.id ? ' active' : ''),
    onClick: () => setView(n.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: n.icon,
    size: 17
  }), n.label, n.countKey && counts[n.countKey] != null && /*#__PURE__*/React.createElement("span", {
    className: "count"
  }, counts[n.countKey])))), /*#__PURE__*/React.createElement("div", {
    className: "side-foot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Cases"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "8")), /*#__PURE__*/React.createElement("div", {
    className: "row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Work items"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "38")), /*#__PURE__*/React.createElement("div", {
    className: "row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Citations"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "100%"))));
}
function ComplianceBanner() {
  return /*#__PURE__*/React.createElement("div", {
    className: "compliance"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "t"
  }, "Synthetic data only \xB7 human review required"), /*#__PURE__*/React.createElement("span", {
    className: "s"
  }, "No PHI \xB7 no external APIs \xB7 no real payer submission. Copilot output is assistive only."), /*#__PURE__*/React.createElement("span", {
    className: "pill"
  }, "Guardrails on"));
}
function SurfaceHead({
  eyebrow,
  title,
  sub,
  actions
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "surface-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "titles"
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, eyebrow), /*#__PURE__*/React.createElement("h1", null, title), sub && /*#__PURE__*/React.createElement("p", null, sub)), actions);
}
Object.assign(window, {
  NAV,
  Badge,
  StatusPill,
  Sidebar,
  ComplianceBanner,
  SurfaceHead
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/copilot/components.jsx", error: String((e && e.message) || e) }); }

// ui_kits/copilot/dashboard.jsx
try { (() => {
// Manager dashboard surface.
function Dashboard({
  onOpenQueue
}) {
  const m = CITRON_DATA.metrics;
  const top = [...CITRON_DATA.items].sort((a, b) => b.amountNum - a.amountNum).slice(0, 4);
  const maxFriction = Math.max(...CITRON_DATA.payerFriction.map(p => p.score));
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(SurfaceHead, {
    eyebrow: "Manager dashboard",
    title: "Today's revenue-cycle picture",
    sub: "Deterministic detectors surface the work; every item below cites synthetic evidence and requires human review.",
    actions: /*#__PURE__*/React.createElement("button", {
      className: "btn btn-secondary btn-sm"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "file-text",
      size: 15
    }), "Export summary")
  }), /*#__PURE__*/React.createElement("div", {
    className: "stat-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "stat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lab"
  }, "Dollars at risk"), /*#__PURE__*/React.createElement("div", {
    className: "val"
  }, m.dollarsAtRisk), /*#__PURE__*/React.createElement("div", {
    className: "delta up"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "trending-up",
    size: 13
  }), "8% vs last week")), /*#__PURE__*/React.createElement("div", {
    className: "stat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lab"
  }, "Urgent items"), /*#__PURE__*/React.createElement("div", {
    className: "val hl"
  }, m.urgentItems), /*#__PURE__*/React.createElement("div", {
    className: "delta down"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "trending-down",
    size: 13
  }), "3 resolved today")), /*#__PURE__*/React.createElement("div", {
    className: "stat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lab"
  }, "Open work items"), /*#__PURE__*/React.createElement("div", {
    className: "val"
  }, m.workItems), /*#__PURE__*/React.createElement("div", {
    className: "delta flat"
  }, "across 5 reviewer roles")), /*#__PURE__*/React.createElement("div", {
    className: "stat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lab"
  }, "Citation completeness"), /*#__PURE__*/React.createElement("div", {
    className: "val"
  }, m.citationCompleteness), /*#__PURE__*/React.createElement("div", {
    className: "delta down"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-check",
    size: 13
  }), "all items cite evidence"))), /*#__PURE__*/React.createElement("div", {
    className: "cols"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("h3", null, "Highest-dollar work"), /*#__PURE__*/React.createElement("span", {
    className: "meta"
  }, "sorted by amount at risk")), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Priority"), /*#__PURE__*/React.createElement("th", null, "Work item"), /*#__PURE__*/React.createElement("th", null, "Payer"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "At risk"))), /*#__PURE__*/React.createElement("tbody", null, top.map(it => /*#__PURE__*/React.createElement("tr", {
    key: it.id,
    style: {
      cursor: 'pointer'
    },
    onClick: () => onOpenQueue(it.id)
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Badge, {
    band: it.priority
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      color: 'var(--ink-900)'
    }
  }, it.title), /*#__PURE__*/React.createElement("div", {
    className: "code",
    style: {
      marginTop: 2
    }
  }, it.claimId, " \xB7 CPT ", it.cpt)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "mono code"
  }, it.payer)), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, it.amount))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("h3", null, "Priority mix")), /*#__PURE__*/React.createElement("div", {
    className: "bars"
  }, CITRON_DATA.priorityMix.map(p => {
    const total = CITRON_DATA.priorityMix.reduce((s, x) => s + x.n, 0);
    return /*#__PURE__*/React.createElement("div", {
      className: "bar-row",
      key: p.band
    }, /*#__PURE__*/React.createElement("span", {
      className: "nm"
    }, p.band), /*#__PURE__*/React.createElement("span", {
      className: "bar-track"
    }, /*#__PURE__*/React.createElement("span", {
      className: "bar-fill",
      style: {
        width: p.n / total * 100 + '%',
        background: p.color
      }
    })), /*#__PURE__*/React.createElement("span", {
      className: "n"
    }, p.n));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("h3", null, "Synthetic payer friction")), /*#__PURE__*/React.createElement("div", {
    className: "bars"
  }, CITRON_DATA.payerFriction.map(p => /*#__PURE__*/React.createElement("div", {
    className: "bar-row",
    key: p.payer
  }, /*#__PURE__*/React.createElement("span", {
    className: "nm mono",
    style: {
      fontSize: 12
    }
  }, p.payer), /*#__PURE__*/React.createElement("span", {
    className: "bar-track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "bar-fill",
    style: {
      width: p.score / maxFriction * 100 + '%',
      background: 'var(--pine-500)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "n"
  }, p.score.toFixed(2)))))))));
}
window.Dashboard = Dashboard;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/copilot/dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/copilot/data.js
try { (() => {
// Citron RCM Copilot — synthetic dataset (derived from parrak/pixel data/asc_cases).
// Synthetic only. No PHI. Draft language mirrors asc_rcm_lite/copilot/*.py verbatim.
window.CITRON_DATA = {
  roles: ['Manager', 'Biller', 'Denial specialist', 'Coder', 'Auth specialist'],
  metrics: {
    dollarsAtRisk: '$142,300',
    urgentItems: 14,
    workItems: 38,
    citationCompleteness: '100%'
  },
  // priority breakdown for dashboard
  priorityMix: [{
    band: 'High',
    n: 14,
    color: 'var(--danger-600)'
  }, {
    band: 'Medium',
    n: 16,
    color: 'var(--warning-600)'
  }, {
    band: 'Low',
    n: 8,
    color: 'var(--info-600)'
  }],
  payerFriction: [{
    payer: 'PAYER-COM-B',
    score: 0.82,
    denials: 9
  }, {
    payer: 'PAYER-COM-H',
    score: 0.74,
    denials: 7
  }, {
    payer: 'PAYER-COM-D',
    score: 0.61,
    denials: 5
  }, {
    payer: 'PAYER-GOV-A',
    score: 0.39,
    denials: 3
  }],
  rootCauses: [{
    cause: 'Missing prior authorization',
    n: 11
  }, {
    cause: 'Medical necessity documentation',
    n: 8
  }, {
    cause: 'Modifier / bundling edits',
    n: 6
  }, {
    cause: 'Charge capture gaps',
    n: 4
  }],
  // Work queue items
  items: [{
    id: 'WQ-002',
    queue: 'denial',
    priority: 'High',
    owner: 'Denial specialist',
    title: 'Authorization denial follow-up',
    caseId: 'ASC-CASE-002',
    claimId: 'CLM-002',
    payer: 'PAYER-COM-B',
    cpt: '64483',
    denialCode: 'CO-197',
    status: 'denied',
    amount: '$3,600.00',
    amountNum: 3600,
    due: '2026-02-05',
    dueSoon: true,
    scenario: 'Missing prior authorization denial',
    facility: 'FAC-ASC-01',
    specialty: 'Pain management',
    serviceDate: '2026-01-12',
    opportunity: 'Possible opportunity for reviewer validation: claim CLM-002 was denied CO-197 “precertification authorization absent.” Review whether retro authorization or a documented emergency exception is available.',
    evidence: [{
      src: 'SRC-002-POLICY',
      type: 'synthetic policy',
      excerpt: '“Prior authorization required before service.” — payer policy, CPT 64483'
    }, {
      src: 'SRC-002-835',
      type: 'synthetic remit',
      excerpt: 'Denial CO-197 “Precertification authorization absent.” Denied amount $3,600.00.'
    }, {
      src: 'SRC-002-837',
      type: 'synthetic claim',
      excerpt: 'Claim CLM-002 submitted 2026-01-14, billed $3,600.00, status denied.'
    }],
    draftType: 'Denial summary — for reviewer validation',
    draft: 'Denial summary for reviewer validation: category prior_authorization, appealability possible, and path retro-authorization review (Evidence: SRC-002-POLICY, SRC-002-835). Review whether a documented emergency exception or retro authorization is available before any corrected-claim or appeal workflow. This draft does not guarantee payment or a final coding outcome.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-002-POLICY, SRC-002-835, SRC-002-837.'
  }, {
    id: 'WQ-008',
    queue: 'ar-follow-up',
    priority: 'High',
    owner: 'Biller',
    title: 'High-value 120+ day A/R follow-up',
    caseId: 'ASC-CASE-008',
    claimId: 'CLM-008',
    payer: 'PAYER-COM-H',
    cpt: '27130',
    denialCode: null,
    status: 'open',
    amount: '$76,400.00',
    amountNum: 76400,
    due: '2026-01-05',
    dueSoon: true,
    scenario: 'High-value 120+ day A/R follow-up case',
    facility: 'FAC-ASC-02',
    specialty: 'Orthopedics',
    serviceDate: '2025-08-20',
    opportunity: 'Possible opportunity for reviewer validation: claim CLM-008 (total hip arthroplasty) remains unpaid more than 120 days after submission with high expected reimbursement. Review whether the next step is a payer status call before the contract follow-up deadline.',
    evidence: [{
      src: 'SRC-008-AR',
      type: 'synthetic A/R aging',
      excerpt: 'Claim unpaid 120+ days after 2025-08-24 submission. Expected allowed $24,000.00 + implant carveout.'
    }, {
      src: 'SRC-008-CONTRACT',
      type: 'synthetic contract',
      excerpt: 'High-cost orthopedic case expected allowed amount $24,000.00 plus eligible implant carveout.'
    }, {
      src: 'SRC-008-837',
      type: 'synthetic claim',
      excerpt: 'Claim CLM-008 billed $76,400.00, status open_ar_120_plus.'
    }],
    draftType: 'Payer call script — for reviewer validation',
    draft: 'Payer call script for ASC-CASE-008: review whether the synthetic claim needs follow-up for high_dollar_aging_120_plus and confirm current status, deadlines, and missing items before any external conversation (Evidence: SRC-008-AR, SRC-008-CONTRACT).\nState that this is a synthetic workflow exercise and capture only reviewer-safe next steps.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-008-AR, SRC-008-CONTRACT, SRC-008-837.'
  }, {
    id: 'WQ-005',
    queue: 'coding',
    priority: 'Medium',
    owner: 'Coder',
    title: 'Modifier 59 bundled-procedure risk',
    caseId: 'ASC-CASE-005',
    claimId: 'CLM-005',
    payer: 'PAYER-COM-D',
    cpt: '29881 / 29877',
    denialCode: null,
    status: 'open',
    amount: '$2,150.00',
    amountNum: 2150,
    due: '2026-02-12',
    dueSoon: false,
    scenario: 'Modifier 59 bundled procedure risk',
    facility: 'FAC-ASC-01',
    specialty: 'Orthopedics',
    serviceDate: '2026-01-09',
    opportunity: 'Possible opportunity for reviewer validation: a synthetic NCCI-style edit suggests CPT 29877 may be bundled into 29881 without a distinct-procedure modifier. Review whether modifier 59 is supported by the operative note before claim scrub.',
    evidence: [{
      src: 'SRC-005-OP',
      type: 'synthetic op note',
      excerpt: 'Operative note documents two compartments; distinct-site support requires reviewer confirmation.'
    }, {
      src: 'SRC-005-EDIT',
      type: 'synthetic NCCI edit',
      excerpt: 'Column-2 code 29877 bundles into 29881 absent a distinct-procedure modifier.'
    }],
    draftType: 'Coding QA note — for reviewer validation',
    draft: 'Coding QA note for reviewer validation: review whether modifier 59 (or an X{EPSU} modifier) is supported for CPT 29877 against the operative note before claim scrub (Evidence: SRC-005-OP, SRC-005-EDIT). Please verify against source documentation. This note does not assert a compliant code or a final coding outcome.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-005-OP, SRC-005-EDIT.'
  }, {
    id: 'WQ-004',
    queue: 'denial',
    priority: 'High',
    owner: 'Denial specialist',
    title: 'Medical-necessity denial — missing conservative therapy',
    caseId: 'ASC-CASE-004',
    claimId: 'CLM-004',
    payer: 'PAYER-COM-B',
    cpt: '64635',
    denialCode: 'CO-50',
    status: 'denied',
    amount: '$4,820.00',
    amountNum: 4820,
    due: '2026-02-03',
    dueSoon: true,
    scenario: 'Medical necessity denial with missing conservative therapy support',
    facility: 'FAC-ASC-01',
    specialty: 'Pain management',
    serviceDate: '2025-12-18',
    opportunity: 'Possible opportunity for reviewer validation: denial CO-50 cites medical necessity. Review whether documentation of conservative therapy duration supports an appeal packet.',
    evidence: [{
      src: 'SRC-004-POLICY',
      type: 'synthetic policy',
      excerpt: 'Coverage requires documented conservative therapy of at least 6 weeks prior to procedure.'
    }, {
      src: 'SRC-004-835',
      type: 'synthetic remit',
      excerpt: 'Denial CO-50 “Non-covered: medical necessity not established.”'
    }],
    draftType: 'Evidence checklist — for reviewer validation',
    draft: 'Evidence checklist for reviewer validation: confirm denial evidence, payer policy support, and missing items conservative_therapy_documentation, therapy_duration_note before any appeal or corrected-claim workflow (Evidence: SRC-004-POLICY, SRC-004-835).\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-004-POLICY, SRC-004-835.'
  }, {
    id: 'WQ-006',
    queue: 'coding',
    priority: 'Medium',
    owner: 'Coder',
    title: 'Implant supply charge capture miss',
    caseId: 'ASC-CASE-006',
    claimId: 'CLM-006',
    payer: 'PAYER-COM-H',
    cpt: 'C1776',
    denialCode: null,
    status: 'open',
    amount: '$11,200.00',
    amountNum: 11200,
    due: '2026-02-15',
    dueSoon: false,
    scenario: 'Implant supply charge capture miss',
    facility: 'FAC-ASC-02',
    specialty: 'Orthopedics',
    serviceDate: '2026-01-04',
    opportunity: 'Possible opportunity for reviewer validation: the implant log references a device with no matching supply charge line. Review whether an implant charge (C1776) should be captured before the claim is finalized.',
    evidence: [{
      src: 'SRC-006-IMPLANT',
      type: 'synthetic implant log',
      excerpt: 'Implant log records joint device; no matching charge line found in the charge export.'
    }, {
      src: 'SRC-006-CDM',
      type: 'synthetic charge export',
      excerpt: 'Charge export contains facility charge only; supply line C1776 absent.'
    }],
    draftType: 'Charge capture note — for reviewer validation',
    draft: 'Charge capture note for reviewer validation: review whether an implant supply charge (C1776) is supported by the implant log and should be captured before claim finalization (Evidence: SRC-006-IMPLANT, SRC-006-CDM). Please verify against source documentation.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-006-IMPLANT, SRC-006-CDM.'
  }, {
    id: 'WQ-007',
    queue: 'ar-follow-up',
    priority: 'Low',
    owner: 'Biller',
    title: 'Underpaid commercial cataract claim',
    caseId: 'ASC-CASE-007',
    claimId: 'CLM-007',
    payer: 'PAYER-COM-D',
    cpt: '66984',
    denialCode: null,
    status: 'open',
    amount: '$1,340.00',
    amountNum: 1340,
    due: '2026-02-20',
    dueSoon: false,
    scenario: 'Underpaid commercial cataract claim against simple contract',
    facility: 'FAC-ASC-02',
    specialty: 'Ophthalmology',
    serviceDate: '2025-12-29',
    opportunity: 'Possible opportunity for reviewer validation: remit amount appears below the synthetic contract allowed amount. Review whether an underpayment recovery follow-up is appropriate.',
    evidence: [{
      src: 'SRC-007-CONTRACT',
      type: 'synthetic contract',
      excerpt: 'Contract allowed amount $2,180.00 for CPT 66984.'
    }, {
      src: 'SRC-007-835',
      type: 'synthetic remit',
      excerpt: 'Paid amount $840.00 against billed $2,180.00.'
    }],
    draftType: 'Next-best-action — for reviewer validation',
    draft: 'Next-best-action explanation for ASC-CASE-007: review whether the next step should be an underpayment recovery follow-up because the deterministic flag reason is a remit below the synthetic contract allowed amount (Evidence: SRC-007-CONTRACT, SRC-007-835).\nThis explanation is assistive only and does not guarantee payer response or payment.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-007-CONTRACT, SRC-007-835.'
  }, {
    id: 'WQ-003',
    queue: 'coding',
    priority: 'Medium',
    owner: 'Auth specialist',
    title: 'Auth-approved CPT mismatch',
    caseId: 'ASC-CASE-003',
    claimId: 'CLM-003',
    payer: 'PAYER-GOV-A',
    cpt: '63685',
    denialCode: null,
    status: 'open',
    amount: '$5,950.00',
    amountNum: 5950,
    due: '2026-02-10',
    dueSoon: false,
    scenario: 'Auth-approved CPT mismatch',
    facility: 'FAC-ASC-01',
    specialty: 'Neurosurgery',
    serviceDate: '2026-01-07',
    opportunity: 'Possible opportunity for reviewer validation: the authorized CPT does not match the performed CPT on the claim. Review whether an authorization update is needed before submission.',
    evidence: [{
      src: 'SRC-003-AUTH',
      type: 'synthetic auth portal',
      excerpt: 'Authorization approved for a different CPT than the performed procedure.'
    }, {
      src: 'SRC-003-OP',
      type: 'synthetic op note',
      excerpt: 'Operative note documents CPT 63685 as performed.'
    }],
    draftType: 'Authorization gap note — for reviewer validation',
    draft: 'Authorization gap note for reviewer validation: review whether the authorized CPT and the performed CPT 63685 require an authorization update before submission (Evidence: SRC-003-AUTH, SRC-003-OP). Please verify against source documentation.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-003-AUTH, SRC-003-OP.'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/copilot/data.js", error: String((e && e.message) || e) }); }

// ui_kits/copilot/icons.js
try { (() => {
// Citron RCM Copilot — curated Lucide icon set (authentic Lucide path data).
// Rendered as a single <Icon name size/> component. Outline only, 1.75 stroke.
(function () {
  const P = {
    'layout-dashboard': '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
    'list-checks': '<path d="m3 17 2 2 4-4"/><path d="m3 7 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>',
    'scan-line': '<path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M7 12h10"/>',
    'circle-dollar-sign': '<circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 18V6"/>',
    'scale': '<path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/>',
    'network': '<rect x="16" y="16" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="9" y="2" width="6" height="6" rx="1"/><path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"/><path d="M12 12V8"/>',
    'shield-check': '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
    'chevron-right': '<path d="m9 18 6-6-6-6"/>',
    'chevron-left': '<path d="m15 18-6-6 6-6"/>',
    'clock': '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    'search': '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    'link': '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    'circle-check': '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
    'sparkles': '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .962 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.962 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/>',
    'file-text': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/>',
    'alert-triangle': '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    'trending-up': '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
    'trending-down': '<polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/>',
    'phone': '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
    'check': '<path d="M20 6 9 17l-5-5"/>',
    'copy': '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    'flag': '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" x2="4" y1="22" y2="15"/>'
  };
  function Icon({
    name,
    size = 18,
    color = 'currentColor',
    strokeWidth = 1.75,
    style
  }) {
    const inner = P[name] || '';
    return React.createElement('svg', {
      width: size,
      height: size,
      viewBox: '0 0 24 24',
      fill: 'none',
      stroke: color,
      strokeWidth,
      strokeLinecap: 'round',
      strokeLinejoin: 'round',
      style,
      dangerouslySetInnerHTML: {
        __html: inner
      }
    });
  }
  window.Icon = Icon;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/copilot/icons.js", error: String((e && e.message) || e) }); }

// ui_kits/copilot/payer.jsx
try { (() => {
// Payer intelligence surface — aggregate synthetic patterns.
function PayerIntelligence() {
  const maxF = Math.max(...CITRON_DATA.payerFriction.map(p => p.score));
  const maxR = Math.max(...CITRON_DATA.rootCauses.map(r => r.n));
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(SurfaceHead, {
    eyebrow: "Payer intelligence",
    title: "Synthetic payer patterns",
    sub: "Aggregate, synthetic denial and friction patterns. Read-only intelligence \u2014 it informs reviewer work but makes no payer determination."
  }), /*#__PURE__*/React.createElement("div", {
    className: "cols"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("h3", null, "Denials by payer"), /*#__PURE__*/React.createElement("span", {
    className: "meta"
  }, "last 90 days \xB7 synthetic")), /*#__PURE__*/React.createElement("div", {
    className: "panel-body"
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Payer"), /*#__PURE__*/React.createElement("th", null, "Friction"), /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: 'right'
    }
  }, "Denials"))), /*#__PURE__*/React.createElement("tbody", null, CITRON_DATA.payerFriction.map(p => /*#__PURE__*/React.createElement("tr", {
    key: p.payer
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "mono code",
    style: {
      color: 'var(--ink-900)',
      fontWeight: 600
    }
  }, p.payer)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "bar-track",
    style: {
      display: 'inline-block',
      width: 120,
      verticalAlign: 'middle'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "bar-fill",
    style: {
      display: 'block',
      width: p.score / maxF * 100 + '%',
      background: 'var(--pine-500)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      marginLeft: 10,
      fontSize: 12,
      color: 'var(--ink-500)'
    }
  }, p.score.toFixed(2))), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, p.denials))))))), /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("h3", null, "Top preventable root causes")), /*#__PURE__*/React.createElement("div", {
    className: "bars"
  }, CITRON_DATA.rootCauses.map(r => /*#__PURE__*/React.createElement("div", {
    className: "bar-row",
    key: r.cause
  }, /*#__PURE__*/React.createElement("span", {
    className: "nm",
    style: {
      width: 180
    }
  }, r.cause), /*#__PURE__*/React.createElement("span", {
    className: "bar-track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "bar-fill",
    style: {
      width: r.n / maxR * 100 + '%',
      background: 'var(--citron-500)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "n"
  }, r.n)))))));
}
window.PayerIntelligence = PayerIntelligence;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/copilot/payer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/copilot/workqueue.jsx
try { (() => {
// Work queue list + evidence-cited reviewer detail.
const {
  useState: useStateWQ
} = React;
function QueueRow({
  item,
  selected,
  onClick
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'qrow' + (selected ? ' sel' : ''),
    onClick: onClick
  }, /*#__PURE__*/React.createElement("span", {
    className: "pri"
  }, /*#__PURE__*/React.createElement(Badge, {
    band: item.priority
  })), /*#__PURE__*/React.createElement("div", {
    className: "main"
  }, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, item.title), /*#__PURE__*/React.createElement("div", {
    className: "sub"
  }, item.claimId, " \xB7 ", item.payer, " \xB7 CPT ", item.cpt, item.denialCode ? ' · denial ' + item.denialCode : '', " \xB7 ", item.owner)), /*#__PURE__*/React.createElement("span", {
    className: "amt"
  }, item.amount), /*#__PURE__*/React.createElement("span", {
    className: 'due ' + (item.dueSoon ? 'soon' : 'ok')
  }, "Due ", item.due), /*#__PURE__*/React.createElement("span", {
    className: "chev"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18
  })));
}
function WorkQueue({
  filterQueue,
  title,
  eyebrow,
  sub,
  role,
  onOpen
}) {
  const [pri, setPri] = useStateWQ('all');
  const [q, setQ] = useStateWQ('');
  let items = CITRON_DATA.items;
  if (filterQueue) items = items.filter(it => it.queue === filterQueue);
  if (pri !== 'all') items = items.filter(it => it.priority === pri);
  if (q.trim()) {
    const t = q.toLowerCase();
    items = items.filter(it => (it.title + it.claimId + it.payer + it.cpt + it.owner).toLowerCase().includes(t));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement(SurfaceHead, {
    eyebrow: eyebrow,
    title: title,
    sub: sub
  }), /*#__PURE__*/React.createElement("div", {
    className: "chips"
  }, ['all', 'High', 'Medium', 'Low'].map(p => /*#__PURE__*/React.createElement("button", {
    key: p,
    className: 'chip' + (pri === p ? ' on' : ''),
    onClick: () => setPri(p)
  }, p === 'all' ? 'All priorities' : p)), /*#__PURE__*/React.createElement("div", {
    className: "search"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 15
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search claim, CPT, payer\u2026",
    value: q,
    onChange: e => setQ(e.target.value)
  }))), items.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, "No work items match this filter.") : items.map(it => /*#__PURE__*/React.createElement(QueueRow, {
    key: it.id,
    item: it,
    onClick: () => onOpen(it.id)
  })));
}
function ReviewerDetail({
  item,
  onBack
}) {
  const [generated, setGenerated] = useStateWQ(false);
  const [reviewed, setReviewed] = useStateWQ(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "detail-top"
  }, /*#__PURE__*/React.createElement("button", {
    className: "back",
    onClick: onBack
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-left",
    size: 16
  }), "Work queue"), /*#__PURE__*/React.createElement("span", {
    className: "code mono"
  }, item.caseId)), /*#__PURE__*/React.createElement("div", {
    className: "surface-head",
    style: {
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "titles"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, item.scenario), /*#__PURE__*/React.createElement("h1", null, item.title)), /*#__PURE__*/React.createElement(Badge, {
    band: item.priority
  }), /*#__PURE__*/React.createElement(StatusPill, {
    item: item
  })), /*#__PURE__*/React.createElement("div", {
    className: "cols"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("h3", null, "Possible opportunity"), /*#__PURE__*/React.createElement("span", {
    className: "meta"
  }, "deterministic detector")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 18px',
      font: 'var(--body)',
      color: 'var(--ink-700)'
    }
  }, item.opportunity)), /*#__PURE__*/React.createElement("div", {
    className: "section-title"
  }, "Cited evidence \u2014 review first"), item.evidence.map(e => /*#__PURE__*/React.createElement("div", {
    className: "evidence",
    key: e.src
  }, /*#__PURE__*/React.createElement("div", {
    className: "head"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "link",
    size: 14,
    color: "var(--pine-600)"
  }), /*#__PURE__*/React.createElement("span", {
    className: "lab"
  }, e.type), /*#__PURE__*/React.createElement("span", {
    className: "src"
  }, e.src)), /*#__PURE__*/React.createElement("div", {
    className: "ex"
  }, e.excerpt))), /*#__PURE__*/React.createElement("div", {
    className: "section-title"
  }, "Copilot draft \u2014 assistive only"), !generated ? /*#__PURE__*/React.createElement("div", {
    className: "panel",
    style: {
      padding: '22px 18px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--body-sm)',
      color: 'var(--ink-500)',
      marginBottom: 14
    }
  }, "Generate a reviewer-safe draft from the deterministic detector output and cited evidence above."), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    onClick: () => setGenerated(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 16
  }), "Generate ", item.draftType.split(' — ')[0].toLowerCase())) : /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "draft"
  }, /*#__PURE__*/React.createElement("div", {
    className: "draft-head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ttl"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "file-text",
    size: 15
  }), item.draftType), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-ghost btn-sm",
    style: {
      marginLeft: 'auto'
    },
    onClick: () => navigator.clipboard && navigator.clipboard.writeText(item.draft)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "copy",
    size: 14
  }), "Copy")), /*#__PURE__*/React.createElement("div", {
    className: "draft-body"
  }, item.draft)), /*#__PURE__*/React.createElement("div", {
    className: "review-note"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "alert-triangle",
    size: 16
  }), /*#__PURE__*/React.createElement("span", {
    className: "txt"
  }, /*#__PURE__*/React.createElement("b", null, "Human review is required"), " before any payer outreach, appeal, correction, or write-off decision. This draft does not guarantee payment or a final coding outcome.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: 'btn ' + (reviewed ? 'btn-secondary' : 'btn-primary'),
    onClick: () => setReviewed(!reviewed)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: reviewed ? 'circle-check' : 'check',
    size: 15
  }), reviewed ? 'Marked reviewed' : 'Mark reviewed'), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-secondary"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "flag",
    size: 15
  }), "Escalate to manager")))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("h3", null, "Case facts")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '15px 18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "kv"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Case"), /*#__PURE__*/React.createElement("span", {
    className: "v mono"
  }, item.caseId), /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Claim"), /*#__PURE__*/React.createElement("span", {
    className: "v mono"
  }, item.claimId), /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Payer"), /*#__PURE__*/React.createElement("span", {
    className: "v mono"
  }, item.payer), /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "CPT"), /*#__PURE__*/React.createElement("span", {
    className: "v mono"
  }, item.cpt), item.denialCode && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Denial"), /*#__PURE__*/React.createElement("span", {
    className: "v mono"
  }, item.denialCode)), /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Facility"), /*#__PURE__*/React.createElement("span", {
    className: "v mono"
  }, item.facility), /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Specialty"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, item.specialty), /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Service date"), /*#__PURE__*/React.createElement("span", {
    className: "v mono"
  }, item.serviceDate), /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Owner role"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, item.owner), /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Deadline"), /*#__PURE__*/React.createElement("span", {
    className: "v mono"
  }, item.due)))), /*#__PURE__*/React.createElement("div", {
    className: "panel",
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-head"
  }, /*#__PURE__*/React.createElement("h3", null, "Amount at risk")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '700 30px/1 var(--font-mono)',
      color: 'var(--ink-900)',
      fontVariantNumeric: 'tabular-nums',
      letterSpacing: '-.01em'
    }
  }, item.amount), /*#__PURE__*/React.createElement("div", {
    className: "code",
    style: {
      marginTop: 8
    }
  }, "synthetic \xB7 for reviewer validation"))))));
}
Object.assign(window, {
  WorkQueue,
  ReviewerDetail
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/copilot/workqueue.jsx", error: String((e && e.message) || e) }); }

})();
