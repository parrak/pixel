// Shared chrome + primitives for the Citron RCM Copilot kit.
const { useState } = React;

const NAV = [
  { id: 'dashboard', label: 'Manager dashboard', icon: 'layout-dashboard' },
  { id: 'queue', label: 'Work queue', icon: 'list-checks', countKey: 'all' },
  { id: 'coding', label: 'Coding QA', icon: 'scan-line', countKey: 'coding' },
  { id: 'ar', label: 'A/R follow-up', icon: 'circle-dollar-sign', countKey: 'ar-follow-up' },
  { id: 'denials', label: 'Denials & appeals', icon: 'scale', countKey: 'denial' },
  { id: 'payer', label: 'Payer intelligence', icon: 'network' },
];

function Badge({ band }) {
  return (
    <span className={'badge ' + band.toLowerCase()}>
      <span className="dot"></span>{band}
    </span>
  );
}

function StatusPill({ item }) {
  if (item.status === 'denied') return <span className="status denied">Denied · {item.denialCode}</span>;
  if (item.queue === 'ar-follow-up') return <span className="status open">Open A/R · 120+ days</span>;
  return <span className="status open">Open · in review</span>;
}

function Sidebar({ view, setView, role, setRole, counts }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <img src="../../assets/logo-mark.svg" width="30" height="30" alt="" />
        <span className="wm">Citron<b> Health</b></span>
      </div>

      <div className="role">
        <span className="lab">Viewing as</span>
        <select value={role} onChange={(e) => setRole(e.target.value)}>
          {CITRON_DATA.roles.map((r) => <option key={r}>{r}</option>)}
        </select>
      </div>

      <nav className="nav">
        <div className="nav-sect">Command center</div>
        {NAV.map((n) => (
          <button
            key={n.id}
            className={'nav-item' + (view === n.id ? ' active' : '')}
            onClick={() => setView(n.id)}
          >
            <Icon name={n.icon} size={17} />
            {n.label}
            {n.countKey && counts[n.countKey] != null && (
              <span className="count">{counts[n.countKey]}</span>
            )}
          </button>
        ))}
      </nav>

      <div className="side-foot">
        <div className="row"><span className="k">Cases</span><span className="v">8</span></div>
        <div className="row"><span className="k">Work items</span><span className="v">38</span></div>
        <div className="row"><span className="k">Citations</span><span className="v">100%</span></div>
      </div>
    </aside>
  );
}

function ComplianceBanner() {
  return (
    <div className="compliance">
      <span className="ic"><Icon name="shield-check" size={18} /></span>
      <span className="t">Synthetic data only · human review required</span>
      <span className="s">No PHI · no external APIs · no real payer submission. Copilot output is assistive only.</span>
      <span className="pill">Guardrails on</span>
    </div>
  );
}

function SurfaceHead({ eyebrow, title, sub, actions }) {
  return (
    <div className="surface-head">
      <div className="titles">
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1>{title}</h1>
        {sub && <p>{sub}</p>}
      </div>
      {actions}
    </div>
  );
}

Object.assign(window, { NAV, Badge, StatusPill, Sidebar, ComplianceBanner, SurfaceHead });
