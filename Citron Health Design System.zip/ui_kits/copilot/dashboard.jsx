// Manager dashboard surface.
function Dashboard({ onOpenQueue }) {
  const m = CITRON_DATA.metrics;
  const top = [...CITRON_DATA.items].sort((a, b) => b.amountNum - a.amountNum).slice(0, 4);
  const maxFriction = Math.max(...CITRON_DATA.payerFriction.map((p) => p.score));

  return (
    <div className="page">
      <SurfaceHead
        eyebrow="Manager dashboard"
        title="Today's revenue-cycle picture"
        sub="Deterministic detectors surface the work; every item below cites synthetic evidence and requires human review."
        actions={<button className="btn btn-secondary btn-sm"><Icon name="file-text" size={15} />Export summary</button>}
      />

      <div className="stat-grid">
        <div className="stat">
          <div className="lab">Dollars at risk</div>
          <div className="val">{m.dollarsAtRisk}</div>
          <div className="delta up"><Icon name="trending-up" size={13} />8% vs last week</div>
        </div>
        <div className="stat">
          <div className="lab">Urgent items</div>
          <div className="val hl">{m.urgentItems}</div>
          <div className="delta down"><Icon name="trending-down" size={13} />3 resolved today</div>
        </div>
        <div className="stat">
          <div className="lab">Open work items</div>
          <div className="val">{m.workItems}</div>
          <div className="delta flat">across 5 reviewer roles</div>
        </div>
        <div className="stat">
          <div className="lab">Citation completeness</div>
          <div className="val">{m.citationCompleteness}</div>
          <div className="delta down"><Icon name="circle-check" size={13} />all items cite evidence</div>
        </div>
      </div>

      <div className="cols">
        <div className="panel">
          <div className="panel-head">
            <h3>Highest-dollar work</h3>
            <span className="meta">sorted by amount at risk</span>
          </div>
          <div className="panel-body">
            <table className="tbl">
              <thead>
                <tr><th>Priority</th><th>Work item</th><th>Payer</th><th style={{ textAlign: 'right' }}>At risk</th></tr>
              </thead>
              <tbody>
                {top.map((it) => (
                  <tr key={it.id} style={{ cursor: 'pointer' }} onClick={() => onOpenQueue(it.id)}>
                    <td><Badge band={it.priority} /></td>
                    <td>
                      <div style={{ fontWeight: 600, color: 'var(--ink-900)' }}>{it.title}</div>
                      <div className="code" style={{ marginTop: 2 }}>{it.claimId} · CPT {it.cpt}</div>
                    </td>
                    <td><span className="mono code">{it.payer}</span></td>
                    <td className="num">{it.amount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <div className="panel">
            <div className="panel-head"><h3>Priority mix</h3></div>
            <div className="bars">
              {CITRON_DATA.priorityMix.map((p) => {
                const total = CITRON_DATA.priorityMix.reduce((s, x) => s + x.n, 0);
                return (
                  <div className="bar-row" key={p.band}>
                    <span className="nm">{p.band}</span>
                    <span className="bar-track"><span className="bar-fill" style={{ width: (p.n / total * 100) + '%', background: p.color }}></span></span>
                    <span className="n">{p.n}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="panel">
            <div className="panel-head"><h3>Synthetic payer friction</h3></div>
            <div className="bars">
              {CITRON_DATA.payerFriction.map((p) => (
                <div className="bar-row" key={p.payer}>
                  <span className="nm mono" style={{ fontSize: 12 }}>{p.payer}</span>
                  <span className="bar-track"><span className="bar-fill" style={{ width: (p.score / maxFriction * 100) + '%', background: 'var(--pine-500)' }}></span></span>
                  <span className="n">{p.score.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.Dashboard = Dashboard;
