// Work queue list + evidence-cited reviewer detail.
const { useState: useStateWQ } = React;

function QueueRow({ item, selected, onClick }) {
  return (
    <div className={'qrow' + (selected ? ' sel' : '')} onClick={onClick}>
      <span className="pri"><Badge band={item.priority} /></span>
      <div className="main">
        <div className="t">{item.title}</div>
        <div className="sub">{item.claimId} · {item.payer} · CPT {item.cpt}{item.denialCode ? ' · denial ' + item.denialCode : ''} · {item.owner}</div>
      </div>
      <span className="amt">{item.amount}</span>
      <span className={'due ' + (item.dueSoon ? 'soon' : 'ok')}>Due {item.due}</span>
      <span className="chev"><Icon name="chevron-right" size={18} /></span>
    </div>
  );
}

function WorkQueue({ filterQueue, title, eyebrow, sub, role, onOpen }) {
  const [pri, setPri] = useStateWQ('all');
  const [q, setQ] = useStateWQ('');

  let items = CITRON_DATA.items;
  if (filterQueue) items = items.filter((it) => it.queue === filterQueue);
  if (pri !== 'all') items = items.filter((it) => it.priority === pri);
  if (q.trim()) {
    const t = q.toLowerCase();
    items = items.filter((it) =>
      (it.title + it.claimId + it.payer + it.cpt + it.owner).toLowerCase().includes(t));
  }

  return (
    <div className="page">
      <SurfaceHead eyebrow={eyebrow} title={title} sub={sub} />
      <div className="chips">
        {['all', 'High', 'Medium', 'Low'].map((p) => (
          <button key={p} className={'chip' + (pri === p ? ' on' : '')} onClick={() => setPri(p)}>
            {p === 'all' ? 'All priorities' : p}
          </button>
        ))}
        <div className="search">
          <Icon name="search" size={15} />
          <input placeholder="Search claim, CPT, payer…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>
      {items.length === 0
        ? <div className="empty">No work items match this filter.</div>
        : items.map((it) => <QueueRow key={it.id} item={it} onClick={() => onOpen(it.id)} />)}
    </div>
  );
}

function ReviewerDetail({ item, onBack }) {
  const [generated, setGenerated] = useStateWQ(false);
  const [reviewed, setReviewed] = useStateWQ(false);

  return (
    <div className="page">
      <div className="detail-top">
        <button className="back" onClick={onBack}><Icon name="chevron-left" size={16} />Work queue</button>
        <span className="code mono">{item.caseId}</span>
      </div>

      <div className="surface-head" style={{ alignItems: 'center' }}>
        <div className="titles">
          <div className="eyebrow">{item.scenario}</div>
          <h1>{item.title}</h1>
        </div>
        <Badge band={item.priority} />
        <StatusPill item={item} />
      </div>

      <div className="cols">
        {/* LEFT: evidence-first */}
        <div>
          <div className="panel">
            <div className="panel-head"><h3>Possible opportunity</h3><span className="meta">deterministic detector</span></div>
            <div style={{ padding: '14px 18px', font: 'var(--body)', color: 'var(--ink-700)' }}>{item.opportunity}</div>
          </div>

          <div className="section-title">Cited evidence — review first</div>
          {item.evidence.map((e) => (
            <div className="evidence" key={e.src}>
              <div className="head">
                <Icon name="link" size={14} color="var(--pine-600)" />
                <span className="lab">{e.type}</span>
                <span className="src">{e.src}</span>
              </div>
              <div className="ex">{e.excerpt}</div>
            </div>
          ))}

          <div className="section-title">Copilot draft — assistive only</div>
          {!generated ? (
            <div className="panel" style={{ padding: '22px 18px', textAlign: 'center' }}>
              <div style={{ font: 'var(--body-sm)', color: 'var(--ink-500)', marginBottom: 14 }}>
                Generate a reviewer-safe draft from the deterministic detector output and cited evidence above.
              </div>
              <button className="btn btn-primary" onClick={() => setGenerated(true)}>
                <Icon name="sparkles" size={16} />Generate {item.draftType.split(' — ')[0].toLowerCase()}
              </button>
            </div>
          ) : (
            <div>
              <div className="draft">
                <div className="draft-head">
                  <span className="ttl"><Icon name="file-text" size={15} />{item.draftType}</span>
                  <button className="btn btn-ghost btn-sm" style={{ marginLeft: 'auto' }} onClick={() => navigator.clipboard && navigator.clipboard.writeText(item.draft)}>
                    <Icon name="copy" size={14} />Copy
                  </button>
                </div>
                <div className="draft-body">{item.draft}</div>
              </div>
              <div className="review-note">
                <Icon name="alert-triangle" size={16} />
                <span className="txt"><b>Human review is required</b> before any payer outreach, appeal, correction, or write-off decision. This draft does not guarantee payment or a final coding outcome.</span>
              </div>
              <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
                <button className={'btn ' + (reviewed ? 'btn-secondary' : 'btn-primary')} onClick={() => setReviewed(!reviewed)}>
                  <Icon name={reviewed ? 'circle-check' : 'check'} size={15} />{reviewed ? 'Marked reviewed' : 'Mark reviewed'}
                </button>
                <button className="btn btn-secondary"><Icon name="flag" size={15} />Escalate to manager</button>
              </div>
            </div>
          )}
        </div>

        {/* RIGHT: case facts */}
        <div>
          <div className="panel">
            <div className="panel-head"><h3>Case facts</h3></div>
            <div style={{ padding: '15px 18px' }}>
              <div className="kv">
                <span className="k">Case</span><span className="v mono">{item.caseId}</span>
                <span className="k">Claim</span><span className="v mono">{item.claimId}</span>
                <span className="k">Payer</span><span className="v mono">{item.payer}</span>
                <span className="k">CPT</span><span className="v mono">{item.cpt}</span>
                {item.denialCode && (<><span className="k">Denial</span><span className="v mono">{item.denialCode}</span></>)}
                <span className="k">Facility</span><span className="v mono">{item.facility}</span>
                <span className="k">Specialty</span><span className="v">{item.specialty}</span>
                <span className="k">Service date</span><span className="v mono">{item.serviceDate}</span>
                <span className="k">Owner role</span><span className="v">{item.owner}</span>
                <span className="k">Deadline</span><span className="v mono">{item.due}</span>
              </div>
            </div>
          </div>
          <div className="panel" style={{ marginTop: 18 }}>
            <div className="panel-head"><h3>Amount at risk</h3></div>
            <div style={{ padding: '16px 18px' }}>
              <div style={{ font: '700 30px/1 var(--font-mono)', color: 'var(--ink-900)', fontVariantNumeric: 'tabular-nums', letterSpacing: '-.01em' }}>{item.amount}</div>
              <div className="code" style={{ marginTop: 8 }}>synthetic · for reviewer validation</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { WorkQueue, ReviewerDetail });
