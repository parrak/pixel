// Payer intelligence surface — aggregate synthetic patterns.
function PayerIntelligence() {
  const maxF = Math.max(...CITRON_DATA.payerFriction.map((p) => p.score));
  const maxR = Math.max(...CITRON_DATA.rootCauses.map((r) => r.n));
  return (
    <div className="page">
      <SurfaceHead
        eyebrow="Payer intelligence"
        title="Synthetic payer patterns"
        sub="Aggregate, synthetic denial and friction patterns. Read-only intelligence — it informs reviewer work but makes no payer determination."
      />
      <div className="cols">
        <div className="panel">
          <div className="panel-head"><h3>Denials by payer</h3><span className="meta">last 90 days · synthetic</span></div>
          <div className="panel-body">
            <table className="tbl">
              <thead><tr><th>Payer</th><th>Friction</th><th style={{ textAlign: 'right' }}>Denials</th></tr></thead>
              <tbody>
                {CITRON_DATA.payerFriction.map((p) => (
                  <tr key={p.payer}>
                    <td><span className="mono code" style={{ color: 'var(--ink-900)', fontWeight: 600 }}>{p.payer}</span></td>
                    <td>
                      <span className="bar-track" style={{ display: 'inline-block', width: 120, verticalAlign: 'middle' }}>
                        <span className="bar-fill" style={{ display: 'block', width: (p.score / maxF * 100) + '%', background: 'var(--pine-500)' }}></span>
                      </span>
                      <span className="mono" style={{ marginLeft: 10, fontSize: 12, color: 'var(--ink-500)' }}>{p.score.toFixed(2)}</span>
                    </td>
                    <td className="num">{p.denials}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="panel">
          <div className="panel-head"><h3>Top preventable root causes</h3></div>
          <div className="bars">
            {CITRON_DATA.rootCauses.map((r) => (
              <div className="bar-row" key={r.cause}>
                <span className="nm" style={{ width: 180 }}>{r.cause}</span>
                <span className="bar-track"><span className="bar-fill" style={{ width: (r.n / maxR * 100) + '%', background: 'var(--citron-500)' }}></span></span>
                <span className="n">{r.n}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
window.PayerIntelligence = PayerIntelligence;
