// Citron RCM Copilot — synthetic dataset (derived from parrak/pixel data/asc_cases).
// Synthetic only. No PHI. Draft language mirrors asc_rcm_lite/copilot/*.py verbatim.
window.CITRON_DATA = {
  roles: ['Manager', 'Biller', 'Denial specialist', 'Coder', 'Auth specialist'],

  metrics: {
    dollarsAtRisk: '$142,300',
    urgentItems: 14,
    workItems: 38,
    citationCompleteness: '100%',
  },

  // priority breakdown for dashboard
  priorityMix: [
    { band: 'High', n: 14, color: 'var(--danger-600)' },
    { band: 'Medium', n: 16, color: 'var(--warning-600)' },
    { band: 'Low', n: 8, color: 'var(--info-600)' },
  ],

  payerFriction: [
    { payer: 'PAYER-COM-B', score: 0.82, denials: 9 },
    { payer: 'PAYER-COM-H', score: 0.74, denials: 7 },
    { payer: 'PAYER-COM-D', score: 0.61, denials: 5 },
    { payer: 'PAYER-GOV-A', score: 0.39, denials: 3 },
  ],

  rootCauses: [
    { cause: 'Missing prior authorization', n: 11 },
    { cause: 'Medical necessity documentation', n: 8 },
    { cause: 'Modifier / bundling edits', n: 6 },
    { cause: 'Charge capture gaps', n: 4 },
  ],

  // Work queue items
  items: [
    {
      id: 'WQ-002', queue: 'denial', priority: 'High', owner: 'Denial specialist',
      title: 'Authorization denial follow-up',
      caseId: 'ASC-CASE-002', claimId: 'CLM-002', payer: 'PAYER-COM-B',
      cpt: '64483', denialCode: 'CO-197', status: 'denied',
      amount: '$3,600.00', amountNum: 3600, due: '2026-02-05', dueSoon: true,
      scenario: 'Missing prior authorization denial',
      facility: 'FAC-ASC-01', specialty: 'Pain management', serviceDate: '2026-01-12',
      opportunity: 'Possible opportunity for reviewer validation: claim CLM-002 was denied CO-197 “precertification authorization absent.” Review whether retro authorization or a documented emergency exception is available.',
      evidence: [
        { src: 'SRC-002-POLICY', type: 'synthetic policy', excerpt: '“Prior authorization required before service.” — payer policy, CPT 64483' },
        { src: 'SRC-002-835', type: 'synthetic remit', excerpt: 'Denial CO-197 “Precertification authorization absent.” Denied amount $3,600.00.' },
        { src: 'SRC-002-837', type: 'synthetic claim', excerpt: 'Claim CLM-002 submitted 2026-01-14, billed $3,600.00, status denied.' },
      ],
      draftType: 'Denial summary — for reviewer validation',
      draft: 'Denial summary for reviewer validation: category prior_authorization, appealability possible, and path retro-authorization review (Evidence: SRC-002-POLICY, SRC-002-835). Review whether a documented emergency exception or retro authorization is available before any corrected-claim or appeal workflow. This draft does not guarantee payment or a final coding outcome.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-002-POLICY, SRC-002-835, SRC-002-837.',
    },
    {
      id: 'WQ-008', queue: 'ar-follow-up', priority: 'High', owner: 'Biller',
      title: 'High-value 120+ day A/R follow-up',
      caseId: 'ASC-CASE-008', claimId: 'CLM-008', payer: 'PAYER-COM-H',
      cpt: '27130', denialCode: null, status: 'open',
      amount: '$76,400.00', amountNum: 76400, due: '2026-01-05', dueSoon: true,
      scenario: 'High-value 120+ day A/R follow-up case',
      facility: 'FAC-ASC-02', specialty: 'Orthopedics', serviceDate: '2025-08-20',
      opportunity: 'Possible opportunity for reviewer validation: claim CLM-008 (total hip arthroplasty) remains unpaid more than 120 days after submission with high expected reimbursement. Review whether the next step is a payer status call before the contract follow-up deadline.',
      evidence: [
        { src: 'SRC-008-AR', type: 'synthetic A/R aging', excerpt: 'Claim unpaid 120+ days after 2025-08-24 submission. Expected allowed $24,000.00 + implant carveout.' },
        { src: 'SRC-008-CONTRACT', type: 'synthetic contract', excerpt: 'High-cost orthopedic case expected allowed amount $24,000.00 plus eligible implant carveout.' },
        { src: 'SRC-008-837', type: 'synthetic claim', excerpt: 'Claim CLM-008 billed $76,400.00, status open_ar_120_plus.' },
      ],
      draftType: 'Payer call script — for reviewer validation',
      draft: 'Payer call script for ASC-CASE-008: review whether the synthetic claim needs follow-up for high_dollar_aging_120_plus and confirm current status, deadlines, and missing items before any external conversation (Evidence: SRC-008-AR, SRC-008-CONTRACT).\nState that this is a synthetic workflow exercise and capture only reviewer-safe next steps.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-008-AR, SRC-008-CONTRACT, SRC-008-837.',
    },
    {
      id: 'WQ-005', queue: 'coding', priority: 'Medium', owner: 'Coder',
      title: 'Modifier 59 bundled-procedure risk',
      caseId: 'ASC-CASE-005', claimId: 'CLM-005', payer: 'PAYER-COM-D',
      cpt: '29881 / 29877', denialCode: null, status: 'open',
      amount: '$2,150.00', amountNum: 2150, due: '2026-02-12', dueSoon: false,
      scenario: 'Modifier 59 bundled procedure risk',
      facility: 'FAC-ASC-01', specialty: 'Orthopedics', serviceDate: '2026-01-09',
      opportunity: 'Possible opportunity for reviewer validation: a synthetic NCCI-style edit suggests CPT 29877 may be bundled into 29881 without a distinct-procedure modifier. Review whether modifier 59 is supported by the operative note before claim scrub.',
      evidence: [
        { src: 'SRC-005-OP', type: 'synthetic op note', excerpt: 'Operative note documents two compartments; distinct-site support requires reviewer confirmation.' },
        { src: 'SRC-005-EDIT', type: 'synthetic NCCI edit', excerpt: 'Column-2 code 29877 bundles into 29881 absent a distinct-procedure modifier.' },
      ],
      draftType: 'Coding QA note — for reviewer validation',
      draft: 'Coding QA note for reviewer validation: review whether modifier 59 (or an X{EPSU} modifier) is supported for CPT 29877 against the operative note before claim scrub (Evidence: SRC-005-OP, SRC-005-EDIT). Please verify against source documentation. This note does not assert a compliant code or a final coding outcome.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-005-OP, SRC-005-EDIT.',
    },
    {
      id: 'WQ-004', queue: 'denial', priority: 'High', owner: 'Denial specialist',
      title: 'Medical-necessity denial — missing conservative therapy',
      caseId: 'ASC-CASE-004', claimId: 'CLM-004', payer: 'PAYER-COM-B',
      cpt: '64635', denialCode: 'CO-50', status: 'denied',
      amount: '$4,820.00', amountNum: 4820, due: '2026-02-03', dueSoon: true,
      scenario: 'Medical necessity denial with missing conservative therapy support',
      facility: 'FAC-ASC-01', specialty: 'Pain management', serviceDate: '2025-12-18',
      opportunity: 'Possible opportunity for reviewer validation: denial CO-50 cites medical necessity. Review whether documentation of conservative therapy duration supports an appeal packet.',
      evidence: [
        { src: 'SRC-004-POLICY', type: 'synthetic policy', excerpt: 'Coverage requires documented conservative therapy of at least 6 weeks prior to procedure.' },
        { src: 'SRC-004-835', type: 'synthetic remit', excerpt: 'Denial CO-50 “Non-covered: medical necessity not established.”' },
      ],
      draftType: 'Evidence checklist — for reviewer validation',
      draft: 'Evidence checklist for reviewer validation: confirm denial evidence, payer policy support, and missing items conservative_therapy_documentation, therapy_duration_note before any appeal or corrected-claim workflow (Evidence: SRC-004-POLICY, SRC-004-835).\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-004-POLICY, SRC-004-835.',
    },
    {
      id: 'WQ-006', queue: 'coding', priority: 'Medium', owner: 'Coder',
      title: 'Implant supply charge capture miss',
      caseId: 'ASC-CASE-006', claimId: 'CLM-006', payer: 'PAYER-COM-H',
      cpt: 'C1776', denialCode: null, status: 'open',
      amount: '$11,200.00', amountNum: 11200, due: '2026-02-15', dueSoon: false,
      scenario: 'Implant supply charge capture miss',
      facility: 'FAC-ASC-02', specialty: 'Orthopedics', serviceDate: '2026-01-04',
      opportunity: 'Possible opportunity for reviewer validation: the implant log references a device with no matching supply charge line. Review whether an implant charge (C1776) should be captured before the claim is finalized.',
      evidence: [
        { src: 'SRC-006-IMPLANT', type: 'synthetic implant log', excerpt: 'Implant log records joint device; no matching charge line found in the charge export.' },
        { src: 'SRC-006-CDM', type: 'synthetic charge export', excerpt: 'Charge export contains facility charge only; supply line C1776 absent.' },
      ],
      draftType: 'Charge capture note — for reviewer validation',
      draft: 'Charge capture note for reviewer validation: review whether an implant supply charge (C1776) is supported by the implant log and should be captured before claim finalization (Evidence: SRC-006-IMPLANT, SRC-006-CDM). Please verify against source documentation.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-006-IMPLANT, SRC-006-CDM.',
    },
    {
      id: 'WQ-007', queue: 'ar-follow-up', priority: 'Low', owner: 'Biller',
      title: 'Underpaid commercial cataract claim',
      caseId: 'ASC-CASE-007', claimId: 'CLM-007', payer: 'PAYER-COM-D',
      cpt: '66984', denialCode: null, status: 'open',
      amount: '$1,340.00', amountNum: 1340, due: '2026-02-20', dueSoon: false,
      scenario: 'Underpaid commercial cataract claim against simple contract',
      facility: 'FAC-ASC-02', specialty: 'Ophthalmology', serviceDate: '2025-12-29',
      opportunity: 'Possible opportunity for reviewer validation: remit amount appears below the synthetic contract allowed amount. Review whether an underpayment recovery follow-up is appropriate.',
      evidence: [
        { src: 'SRC-007-CONTRACT', type: 'synthetic contract', excerpt: 'Contract allowed amount $2,180.00 for CPT 66984.' },
        { src: 'SRC-007-835', type: 'synthetic remit', excerpt: 'Paid amount $840.00 against billed $2,180.00.' },
      ],
      draftType: 'Next-best-action — for reviewer validation',
      draft: 'Next-best-action explanation for ASC-CASE-007: review whether the next step should be an underpayment recovery follow-up because the deterministic flag reason is a remit below the synthetic contract allowed amount (Evidence: SRC-007-CONTRACT, SRC-007-835).\nThis explanation is assistive only and does not guarantee payer response or payment.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-007-CONTRACT, SRC-007-835.',
    },
    {
      id: 'WQ-003', queue: 'coding', priority: 'Medium', owner: 'Auth specialist',
      title: 'Auth-approved CPT mismatch',
      caseId: 'ASC-CASE-003', claimId: 'CLM-003', payer: 'PAYER-GOV-A',
      cpt: '63685', denialCode: null, status: 'open',
      amount: '$5,950.00', amountNum: 5950, due: '2026-02-10', dueSoon: false,
      scenario: 'Auth-approved CPT mismatch',
      facility: 'FAC-ASC-01', specialty: 'Neurosurgery', serviceDate: '2026-01-07',
      opportunity: 'Possible opportunity for reviewer validation: the authorized CPT does not match the performed CPT on the claim. Review whether an authorization update is needed before submission.',
      evidence: [
        { src: 'SRC-003-AUTH', type: 'synthetic auth portal', excerpt: 'Authorization approved for a different CPT than the performed procedure.' },
        { src: 'SRC-003-OP', type: 'synthetic op note', excerpt: 'Operative note documents CPT 63685 as performed.' },
      ],
      draftType: 'Authorization gap note — for reviewer validation',
      draft: 'Authorization gap note for reviewer validation: review whether the authorized CPT and the performed CPT 63685 require an authorization update before submission (Evidence: SRC-003-AUTH, SRC-003-OP). Please verify against source documentation.\nHuman review is required before any payer outreach, appeal, correction, or write-off decision.\nEvidence reviewed: SRC-003-AUTH, SRC-003-OP.',
    },
  ],
};
